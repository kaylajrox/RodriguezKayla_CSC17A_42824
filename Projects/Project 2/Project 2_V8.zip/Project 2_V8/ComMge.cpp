/* 
 * File:   ComMge.cpp
 * Author: rcc
 * 
 * Created on June 1, 2016, 1:45 PM
 */

#include "ComMge.h"

