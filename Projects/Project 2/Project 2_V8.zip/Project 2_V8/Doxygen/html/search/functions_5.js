var searchData=
[
  ['game',['game',['../main_8cpp.html#aefeb81f83692d3c786f94b4e5bde3e14',1,'main.cpp']]],
  ['getcolor',['getColor',['../class_color.html#a226e0a8acb5b309c208861e42b3820ab',1,'Color']]],
  ['getgames',['getGames',['../class_com_color.html#aad575acc9f49e9d814c69ba335f94ead',1,'ComColor']]],
  ['getlose',['getLose',['../class_com_color.html#a0c1b3cce5a3a8fa717bba2a19ca7f267',1,'ComColor']]],
  ['getn',['getN',['../main_8cpp.html#ac15df63d4422921c8a80c4c59ae3a81b',1,'main.cpp']]],
  ['getname',['getName',['../class_com_color.html#a922ecff57e3d1df3836f4219a0d8a600',1,'ComColor']]],
  ['getspot',['getSpot',['../class_color.html#ab7cca6575e96dd00aa5f1d669ff92cc3',1,'Color']]],
  ['getturn',['getTurn',['../class_user_color.html#a8779e99b2c3a08d6adb35dc020137738',1,'UserColor']]],
  ['getwin',['getWin',['../class_com_color.html#a0702e43bb1f703bf3f12fda75b7cc68d',1,'ComColor']]]
];
