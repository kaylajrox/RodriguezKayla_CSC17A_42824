var searchData=
[
  ['lose',['lose',['../class_com_color.html#a7a1df199e2bf53992df5876e13513a2d',1,'ComColor']]]
];
