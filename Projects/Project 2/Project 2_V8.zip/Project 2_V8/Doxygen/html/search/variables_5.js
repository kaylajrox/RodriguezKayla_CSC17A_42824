var searchData=
[
  ['size',['SIZE',['../class_color.html#a06a3f06500d1596dd4144a86ea8ccb08',1,'Color']]],
  ['spot',['spot',['../class_color.html#a7eae55cb74925a0cf1b67b26c4dbc6e4',1,'Color']]]
];
