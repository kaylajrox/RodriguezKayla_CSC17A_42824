var searchData=
[
  ['cnvperc',['CNVPERC',['../main_8cpp.html#af8c9e6b8e3f0c1102e136fe188ef5992',1,'main.cpp']]],
  ['color',['color',['../class_color.html#af2699143cf46481ff563b1668e157173',1,'Color']]]
];
