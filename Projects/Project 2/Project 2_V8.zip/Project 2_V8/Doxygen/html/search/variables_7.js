var searchData=
[
  ['win',['win',['../class_com_color.html#aa6bae42950b846cda4a3f1ab40410d2d',1,'ComColor']]]
];
