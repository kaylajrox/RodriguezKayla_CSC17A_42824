var searchData=
[
  ['options',['options',['../class_color.html#ace1c06a26592c26e8f3f3342dab0ec14',1,'Color']]]
];
