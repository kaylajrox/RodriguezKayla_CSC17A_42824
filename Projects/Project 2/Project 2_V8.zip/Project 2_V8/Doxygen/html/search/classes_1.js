var searchData=
[
  ['empclass',['EmpClass',['../class_color_1_1_emp_class.html',1,'Color']]]
];
