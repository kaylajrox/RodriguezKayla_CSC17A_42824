var searchData=
[
  ['name',['name',['../class_com_color.html#ae11e8d6c1b2ee6563393994a7c4cf950',1,'ComColor']]]
];
