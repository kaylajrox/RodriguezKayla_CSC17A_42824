var searchData=
[
  ['lder',['lder',['../main_8cpp.html#ac72829562aa63c3a36ffb5cf4e93609d',1,'main.cpp']]],
  ['lderoutput',['lderOutput',['../main_8cpp.html#ab3ec2a5b8a7e70b79f45a644bf16ec95',1,'main.cpp']]],
  ['lose',['lose',['../class_com_color.html#a7a1df199e2bf53992df5876e13513a2d',1,'ComColor']]]
];
