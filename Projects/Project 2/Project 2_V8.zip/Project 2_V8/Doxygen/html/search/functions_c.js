var searchData=
[
  ['setcolor',['setColor',['../class_color.html#a7280363d58cf6ffa1ac56a5a6fad2a5b',1,'Color::setColor()'],['../class_user_color.html#a355f201094ad8195671c32b64967db30',1,'UserColor::setColor()']]],
  ['setgames',['setGames',['../class_com_color.html#ab3f3e89271cfc8008e43d35555860789',1,'ComColor']]],
  ['setlose',['setLose',['../class_com_color.html#ae20ac317b55c43c9d36f00d45c5ab5d1',1,'ComColor']]],
  ['setname',['setName',['../class_com_color.html#a5ff93ceccbe8da009b4960524de19e98',1,'ComColor']]],
  ['setspot',['setSpot',['../class_color.html#aeac4a669d65d428f65ee0eadee8a9b65',1,'Color']]],
  ['setturn',['setTurn',['../class_user_color.html#ad644e84395664185083b4952d124cdc4',1,'UserColor']]],
  ['setwin',['setWin',['../class_com_color.html#ac193045c0dbcd3f4b2d0d899f5f4587a',1,'ComColor']]],
  ['switchh',['switchH',['../main_8cpp.html#a0222f6cd9ecf19fb963a7d294053cfe4',1,'main.cpp']]]
];
