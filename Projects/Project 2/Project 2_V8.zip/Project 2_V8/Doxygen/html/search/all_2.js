var searchData=
[
  ['datainfile',['dataInfile',['../main_8cpp.html#a666d7ed79c7bac492ca5cb2ccfe91690',1,'main.cpp']]],
  ['def',['def',['../main_8cpp.html#a553100e8b5eb9d1f54bc18877ce00d77',1,'main.cpp']]]
];
