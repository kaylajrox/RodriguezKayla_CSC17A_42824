var searchData=
[
  ['win',['win',['../class_com_color.html#aa6bae42950b846cda4a3f1ab40410d2d',1,'ComColor']]],
  ['writedata',['writeData',['../main_8cpp.html#ac73e2b243e3a2e405fb7355bf5b136da',1,'main.cpp']]],
  ['writefile',['writeFile',['../main_8cpp.html#af5316a018eab2c7fdd17c5c7bf553c66',1,'main.cpp']]]
];
