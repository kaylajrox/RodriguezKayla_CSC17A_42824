var searchData=
[
  ['turn',['turn',['../class_user_color.html#a13888801a0b7cf00a009b723bf8579a2',1,'UserColor']]]
];
