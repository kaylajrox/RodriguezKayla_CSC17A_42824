var searchData=
[
  ['hints1',['hints1',['../main_8cpp.html#a9afe0e6da6eb92815dfa604109bb14ea',1,'main.cpp']]],
  ['hints2',['hints2',['../main_8cpp.html#af3a1d0c93e8d8cc59b9c89d3d67eca14',1,'main.cpp']]],
  ['hints3',['hints3',['../main_8cpp.html#ad0456f0ffc6ee0b1ee5a883a5036d25b',1,'main.cpp']]]
];
