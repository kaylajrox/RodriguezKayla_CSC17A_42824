var searchData=
[
  ['cnvperc',['CNVPERC',['../main_8cpp.html#af8c9e6b8e3f0c1102e136fe188ef5992',1,'main.cpp']]],
  ['color',['color',['../struct_user_color.html#add9733150a6f115a8e88a9ab0fad0625',1,'UserColor']]]
];
