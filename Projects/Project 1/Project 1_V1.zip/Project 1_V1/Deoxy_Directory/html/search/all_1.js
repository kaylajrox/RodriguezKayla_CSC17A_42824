var searchData=
[
  ['cnvperc',['CNVPERC',['../main_8cpp.html#af8c9e6b8e3f0c1102e136fe188ef5992',1,'main.cpp']]],
  ['color',['color',['../struct_user_color.html#add9733150a6f115a8e88a9ab0fad0625',1,'UserColor']]],
  ['comcolor',['ComColor',['../class_com_color.html',1,'ComColor'],['../class_com_color.html#ae2129f4f32961192bca44639b94bbd96',1,'ComColor::ComColor()']]],
  ['comcolor_2ecpp',['ComColor.cpp',['../_com_color_8cpp.html',1,'']]],
  ['comcolor_2eh',['ComColor.h',['../_com_color_8h.html',1,'']]],
  ['compic',['compic',['../main_8cpp.html#a6c044f6351a2ca871ebe06472bbd9538',1,'main.cpp']]]
];
