var searchData=
[
  ['usercolor',['UserColor',['../struct_user_color.html',1,'']]]
];
