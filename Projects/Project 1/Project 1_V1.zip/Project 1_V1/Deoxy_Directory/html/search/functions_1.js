var searchData=
[
  ['comcolor',['ComColor',['../class_com_color.html#ae2129f4f32961192bca44639b94bbd96',1,'ComColor']]],
  ['compic',['compic',['../main_8cpp.html#a6c044f6351a2ca871ebe06472bbd9538',1,'main.cpp']]]
];
