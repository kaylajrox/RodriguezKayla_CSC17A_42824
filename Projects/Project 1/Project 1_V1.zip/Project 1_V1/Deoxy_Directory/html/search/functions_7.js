var searchData=
[
  ['setcolor',['setColor',['../class_com_color.html#a6d989fefe9924daeed27bc2f0aefde1c',1,'ComColor']]],
  ['switchh',['switchH',['../main_8cpp.html#a4160c60a48f2342386d43779b97f02a5',1,'main.cpp']]]
];
