var searchData=
[
  ['spot',['spot',['../struct_user_color.html#ad16f5ac70ad43cb17fb4699fcea6ded3',1,'UserColor']]]
];
