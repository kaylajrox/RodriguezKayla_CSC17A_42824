var searchData=
[
  ['getcolor',['getColor',['../class_com_color.html#a73db07e496d460c11fac99d6eb7a806b',1,'ComColor']]]
];
