#include <iostream>
#include "Circle.h"
using namespace std;

Circle::Circle(){
    radius=0.0;
}