/* 
 * File:   DayOfYear.h
 * Author: Kayla
 *
 * Created on May 12, 2016, 1:47 PM
 */

#ifndef DAYOFYEAR_H
#define DAYOFYEAR_H

class DayOfYear {
private:
    int day;
public:
    DayOfYear();
    print(int);
    leapYear(int);
};

#endif /* DAYOFYEAR_H */

